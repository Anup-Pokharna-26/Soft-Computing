import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

# Load the Iris dataset
iris = load_iris()

# Convert to DataFrame
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)

# Display the first 5 rows
print("First 5 rows of the dataset:")
print(df.head())

# Add the target column
df['target'] = iris.target

# Correct species name mapping
species_map = {0: 'Setosa', 1: 'Versicolor', 2: 'Virginica'}
print("\nSpecies Mapping:", species_map)

# Map target values to species names
df['species'] = df['target'].map(species_map)

# Display species column
print("\nSpecies Column:")
print(df[['target', 'species']].tail(10))  # Display first 10 rows with target and species names

# Create a scatter plot
plt.figure(figsize=(8,6))

# Plot each species separately
for species in species_map.values():
    subset = df[df['species'] == species]
    plt.scatter(subset['sepal length (cm)'], subset['sepal width (cm)'], label=species)

# Add labels and title
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Sepal Width (cm)')
plt.legend()
plt.title('Iris Dataset: Sepal Length vs Sepal Width')
plt.show()
