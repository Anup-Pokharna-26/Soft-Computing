import matplotlib.pyplot as plt
import numpy as np
# from scipy.stats import norm
# import math
# import random
import skfuzzy.membership
import pandas as pd

a = float(input("Enter a: "))
b = float(input("Enter b: "))
c = float(input("Enter c: "))
d = float(input("Enter d: "))

X=(a,b,c,d)
Y=(0,1,1,0)
plt.plot(X,Y)
plt.show()

x=float(input("Enter the element: "))
if x <= a:
    mem = 0
elif x > a and x <= b :
    mem = (x - a) / (b - a)
elif x > b and x < c :
    mem = 1
elif x >= c and x <= d :
    mem = (d - x) / (d - c)
else :    
    mem=0
    
print("Membership :",mem)