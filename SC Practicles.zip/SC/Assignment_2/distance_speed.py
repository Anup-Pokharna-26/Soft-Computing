# Used for creating numerical arrays.
import numpy as np 
# A fuzzy logic library for fuzzy control systems.
import skfuzzy as fuzz 
# Provides tools for defining fuzzy control systems.
from skfuzzy import control as ctrl

# ctrl.Antecedent is used to define an input fuzzy variable.
speed = ctrl.Antecedent(np.arange(0, 101, 1), 'speed')
# ctrl.Antecedent is used to define an output fuzzy variable.
distance = ctrl.Consequent(np.arange(0, 101, 1), 'distance')

# creates a triangular membership function with three points:
speed['slow'] = fuzz.trimf(speed.universe, [0, 0, 50]) # left point is 0, peack point is 0 and right point is 50
speed['medium'] = fuzz.trimf(speed.universe, [30, 50, 70]) # left point is 30, peack point is 50 and right point is 70
speed['fast'] = fuzz.trimf(speed.universe, [50, 100, 100]) # # left point is 50, peack point is 100 and right point is 100


distance['close'] = fuzz.trimf(distance.universe, [0, 0, 30])
distance['moderate'] = fuzz.trimf(distance.universe, [20, 40, 60])
distance['far'] = fuzz.trimf(distance.universe, [50, 100, 100])

# ctrl.rule is used to define rule for fuzzy control system 
rule1 = ctrl.Rule(speed['slow'], distance['close'])
rule2 = ctrl.Rule(speed['medium'], distance['moderate'])
rule3 = ctrl.Rule(speed['fast'], distance['far'])

# ctrl.ControlSystem is used to create fuzzy control system based on rules defined
distance_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])

# ctrl.ControlSystemSimulation is used to simulate fuzzy control system 
distance_sim = ctrl.ControlSystemSimulation(distance_ctrl)

# input for speed
distance_sim.input['speed'] = 60

# compute
distance_sim.compute()

# output
print(f"Distance to Obstacle: {distance_sim.output['distance']:.2f}m")