import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

#Input and output for AC and room temperature
ac_speed = ctrl.Antecedent(np.arange(0,101,1),'ac_speed')
temperature = ctrl.Consequent(np.arange(10, 41, 1), 'temperature') 

# temperature = ctrl.Consequent(np.array(10,41,1),'temperature')

#2. Define membership function ac
ac_speed['low'] = fuzz.trimf(ac_speed.universe, [0, 0, 50]) 
ac_speed['mediam'] = fuzz.trimf(ac_speed.universe,[30,50,70]) #speed 30 -70%
ac_speed['high'] = fuzz.trimf(ac_speed.universe,[50,100,100]) #speed 50 -100%

#3. Define membership function room  temp

temperature['cold'] = fuzz.trimf(temperature.universe,[10,10,20]) #speed 10 -20 C
temperature['comfortable'] = fuzz.trimf(temperature.universe,[15,25,30]) #speed 15 -30%
temperature['hot'] = fuzz.trimf(temperature.universe,[50,100,100]) #speed 35 -40%


#4. Define fuzzy rule

rule1 = ctrl.Rule(ac_speed['low'],temperature['cold'])
rule2 = ctrl.Rule(ac_speed['mediam'],temperature['comfortable'])
rule3 = ctrl.Rule(ac_speed['high'],temperature['hot'])

#5. create the control system

temp_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
temp_sim = ctrl.ControlSystemSimulation(temp_ctrl)

#6. set input ac speed and compute output
temp_sim.input['ac_speed'] = 60
temp_sim.compute()

#print the result 
print(f"Room temperature:{temp_sim.output['temperature']:.2f}°C")