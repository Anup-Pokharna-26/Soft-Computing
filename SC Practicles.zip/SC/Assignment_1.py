""" Fuzzy login operations"""

A = [(1,0.8), (2,0.7), (3,0.1), (4,1.0), (5,0.9), (6,0.3)]
B = [(1,0.3), (2,0.4), (3,0.4), (4,1.0), (5,0), (6,0)]

def union(A,B):
    union_list = []
    for tup1 in A:
        for tup2 in B:
            if tup1[0] == tup2[0]:
                union_list.append((tup1[0] , max(tup1[0] , tup2[0])))
    return union_list

def intersection(A,B):
    intersection_list = []
    for tup1 in A:
        for tup2 in B:
            if tup1[0] == tup2[0]:
                intersection_list.append((tup1[0] , min(tup1[0] , tup2[0])))
    return intersection_list

def complement(A):
    complement_list = []
    for tup1 in A:
        complement_list.append((tup1[0] , 1-tup1[1]))
    return complement_list


def difference(A,B):
    difference_list = []
    B_comp = complement(B)
    
    for tup1 in A:
        for tup2 in B_comp:
            if tup1[0] == tup2[0]:
                difference_list.append((tup1[0] , min(tup1[1] , tup2[1])))
    return difference_list


# ouput : ((1,1) , min(tup1 , tup2) , )
def cartesian_product(A,B):
    cartesian_product_list = []
    for tup1 in A:
        for tup2 in B:
            cartesian_product_list.append(((tup1[0] , tup2[0]) , min(tup1[1] , tup2[1])))
    return cartesian_product_list


def composition():
    pass

print("\n\nUnion of Set A and B ::\n",union(A,B))
print("\n\nIntersection of Set A and B ::\n",intersection(A,B))
print("\n\nComplement of Set A ::\n",complement(A))
print("\n\nDifference of Set A and B ::\n",difference(A,B))
print("\n\nCartesian Product of Set A and B ::\n", cartesian_product(A,B))
